// PetVida — lógica do sistema (JavaScript puro, sem backend). Dados salvos no localStorage do navegador.
const KEY = 'petvida-demo-v1';
let db = carregar();

function carregar() {
  try { const s = localStorage.getItem(KEY); if (s) return JSON.parse(s); } catch (e) {}
  return structuredClone(DADOS);
}
function salvar() { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) {} }

const $ = s => document.querySelector(s);
const esc = t => String(t).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = iso => iso.split('-').reverse().join('/');
const diasAte = iso => Math.round((new Date(iso + 'T00:00') - new Date(dia(0) + 'T00:00')) / 864e5);
const pet = id => db.pets.find(p => p.id == id);
const tutor = id => db.tutores.find(t => t.id == id);
const prof = id => db.profs.find(p => p.id == id);
const opts = (lista, val, txt) => lista.map(x => `<option value="${x[val] ?? x}">${esc(txt ? txt(x) : x)}</option>`).join('');
const proxId = lista => Math.max(0, ...lista.map(x => x.id)) + 1;

// Situação de uma vacina/retorno: em dia, vence em breve ou atrasada
function situacao(v) {
  const d = diasAte(v.proxima);
  if (d < 0) return ['atraso', `Atrasada ${-d} dia(s)`];
  if (d <= 30) return ['aviso', `Vence em ${d} dia(s)`];
  return ['ok', 'Em dia'];
}
const pendentes = () => db.vacinas.filter(v => diasAte(v.proxima) <= 30 && !v.enviado);

// ---------- Telas ----------
const telas = {
  dashboard() {
    const total = HORAS.length * db.profs.length, livres = total - db.ag.length;
    const conf = db.ag.filter(a => a.status != 'Agendado').length;
    const barras = db.profs.map(p => {
      const n = db.ag.filter(a => a.prof == p.id).length, pct = Math.round(n / HORAS.length * 100);
      return `<div>${esc(p.nome)} <small>(${pct}% ocupado)</small><div class="barra"><i style="width:${pct}%"></i></div></div>`;
    }).join('');
    return `<h1>Dashboard</h1><p class="sub">Visão geral do dia — ${fmt(dia(0))}</p>
    <div class="cards">
      <div class="card"><b>${db.ag.length}</b><span>Atendimentos hoje</span></div>
      <div class="card"><b>${Math.round(conf / db.ag.length * 100) || 0}%</b><span>Confirmados ou concluídos</span></div>
      <div class="card alerta"><b>${livres}</b><span>Horários livres (lacunas)</span></div>
      <div class="card alerta"><b>${pendentes().length}</b><span>Lembretes a enviar</span></div>
    </div>
    <h2>Ocupação por profissional</h2><div class="box">${barras}</div>
    <h2>Próximas vacinas e retornos</h2><div class="box">${listaLembretes(db.vacinas.filter(v => diasAte(v.proxima) <= 30).slice(0, 4), false)}</div>`;
  },

  agenda() {
    let h = `<h1>Agenda de hoje</h1><p class="sub">Veterinários e tosadores na mesma agenda. Clique em “+ livre” para agendar ou em um horário para mudar o status.</p>
    <div class="box"><form id="fAg">
      <label>Pet<select name="pet">${opts(db.pets, 'id', p => `${p.nome} (${tutor(p.tutor).nome})`)}</select></label>
      <label>Serviço<select name="tipo">${opts(Object.keys(TIPOS))}</select></label>
      <label>Profissional<select name="prof">${opts(db.profs, 'id', p => `${p.nome} — ${p.funcao}`)}</select></label>
      <label>Horário<select name="hora">${opts(HORAS)}</select></label>
      <button class="btn">Agendar</button></form><div id="msg" class="msg"></div></div>
    <h2>Grade</h2><div class="rolagem"><table class="grade"><tr><th></th>${db.profs.map(p => `<th>${esc(p.nome)}<small>${p.funcao}</small></th>`).join('')}</tr>`;
    for (const hora of HORAS) {
      h += `<tr><td>${hora}</td>`;
      for (const p of db.profs) {
        const a = db.ag.find(x => x.prof == p.id && x.hora == hora);
        h += a ? `<td><div class="ag ${a.status}" data-ag="${a.id}"><b>${esc(pet(a.pet).nome)}</b>${a.tipo} · ${a.status}</div></td>`
               : `<td><button class="livre" data-p="${p.id}" data-h="${hora}">+ livre</button></td>`;
      }
      h += '</tr>';
    }
    return h + '</table></div>';
  },

  cadastros() {
    return `<h1>Tutores e Pets</h1><p class="sub">Cadastro único: tutor, pets e histórico ficam ligados.</p>
    <div class="dupla">
      <div class="box"><h2>Novo tutor</h2><form id="fTutor"><label>Nome<input name="nome" required></label><label>Telefone<input name="tel" required placeholder="(41) 90000-0000"></label><button class="btn">Cadastrar</button></form></div>
      <div class="box"><h2>Novo pet</h2><form id="fPet"><label>Nome<input name="nome" required></label>
        <label>Espécie<select name="especie"><option>Cão</option><option>Gato</option><option>Outro</option></select></label>
        <label>Raça<input name="raca" required></label>
        <label>Tutor<select name="tutor">${opts(db.tutores, 'id', t => t.nome)}</select></label><button class="btn">Cadastrar</button></form></div>
    </div>
    <h2>Pets cadastrados</h2><div class="rolagem"><table><tr><th>Pet</th><th>Espécie / Raça</th><th>Tutor</th><th>Telefone</th><th></th></tr>
    ${db.pets.map(p => `<tr><td>${esc(p.nome)}</td><td>${esc(p.especie)} / ${esc(p.raca)}</td><td>${esc(tutor(p.tutor).nome)}</td><td>${esc(tutor(p.tutor).tel)}</td><td><a class="lnk" href="#prontuario/${p.id}">Ver prontuário</a></td></tr>`).join('')}</table></div>`;
  },

  prontuario(id) {
    id = id || db.pets[0].id;
    const p = pet(id), hist = db.historico.filter(x => x.pet == id).sort((a, b) => b.data.localeCompare(a.data));
    return `<h1>Prontuário</h1><p class="sub">Histórico completo em segundos — consultas, vacinas e banhos no mesmo lugar.</p>
    <label>Pet<select id="selPet">${db.pets.map(x => `<option value="${x.id}" ${x.id == id ? 'selected' : ''}>${esc(x.nome)}</option>`).join('')}</select></label>
    <div class="box" style="margin-top:12px"><b>${esc(p.nome)}</b> — ${esc(p.especie)}, ${esc(p.raca)}<br><small>Tutor: ${esc(tutor(p.tutor).nome)} · ${esc(tutor(p.tutor).tel)}</small></div>
    <div class="dupla"><div><h2>Vacinas e retornos</h2><div class="box">${listaLembretes(db.vacinas.filter(v => v.pet == id), false) || 'Nenhum registro.'}</div></div>
    <div><h2>Linha do tempo</h2><div class="box">${hist.map(x => `<div class="linha"><b>${x.tipo}</b> · ${fmt(x.data)}<br><small>${esc(x.texto)}</small></div>`).join('') || 'Sem histórico.'}</div></div></div>`;
  },

  lembretes() {
    const lista = db.vacinas.filter(v => diasAte(v.proxima) <= 30);
    return `<h1>Lembretes</h1><p class="sub">Vacinas e retornos preventivos que vencem em até 30 dias. Cada lembrete enviado leva o tutor de volta à agenda.</p>
    ${listaLembretes(lista, true) || '<div class="box">Nenhum lembrete pendente 🎉</div>'}<div id="previa"></div>`;
  },

  equipe() {
    return `<h1>Equipe</h1><p class="sub">${db.profs.length} profissionais · ${db.recepcao || 2} recepcionistas</p>
    <div class="rolagem"><table><tr><th>Nome</th><th>Função</th><th>Observação</th><th>Atendimentos hoje</th></tr>
    ${db.profs.map(p => `<tr><td>${esc(p.nome)}</td><td>${p.funcao}</td><td>${esc(p.obs)}</td><td>${db.ag.filter(a => a.prof == p.id).length}</td></tr>`).join('')}</table></div>`;
  }
};

// Lista de vacinas/retornos; com acoes=true mostra botão de lembrete
function listaLembretes(lista, acoes) {
  if (!lista.length) return '';
  return `<div class="rolagem"><table><tr><th>Pet</th><th>Item</th><th>Data</th><th>Situação</th>${acoes ? '<th>Ação</th>' : ''}</tr>` +
    lista.map(v => {
      const [cls, txt] = situacao(v), i = db.vacinas.indexOf(v);
      return `<tr><td>${esc(pet(v.pet).nome)}</td><td>${esc(v.nome)}</td><td>${fmt(v.proxima)}</td><td><span class="tag ${cls}">${txt}</span></td>` +
        (acoes ? `<td>${v.enviado ? '✔ Enviado' : `<button class="btn" data-lem="${i}">Enviar lembrete</button>`}</td>` : '') + '</tr>';
    }).join('') + '</table></div>';
}

// ---------- Navegação ----------
function rota() {
  const [nome, param] = (location.hash.slice(1) || 'dashboard').split('/');
  const tela = telas[nome] || telas.dashboard;
  $('#app').innerHTML = tela(param);
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('on', a.hash == '#' + nome));
  ligarEventos();
}

function aviso(texto, ok) { const m = $('#msg'); m.className = 'msg ' + (ok ? 'ok' : 'erro'); m.textContent = texto; }

function ligarEventos() {
  const f = $('#fAg');
  if (f) f.onsubmit = e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(f)); d.pet = +d.pet; d.prof = +d.prof;
    const pr = prof(d.prof);
    if (TIPOS[d.tipo] != pr.funcao) return aviso(`${d.tipo} deve ser feito por ${TIPOS[d.tipo]}.`);
    if (db.ag.some(a => a.prof == d.prof && a.hora == d.hora)) return aviso(`Conflito: ${pr.nome} já tem atendimento às ${d.hora}.`);
    if (db.ag.some(a => a.pet == d.pet && a.hora == d.hora)) return aviso(`Conflito: ${pet(d.pet).nome} já está agendado às ${d.hora}.`);
    db.ag.push({id: proxId(db.ag), ...d, status: 'Agendado'});
    salvar(); rota(); aviso('Agendamento criado sem conflitos ✔', true);
  };
  document.querySelectorAll('.livre').forEach(b => b.onclick = () => {
    f.prof.value = b.dataset.p; f.hora.value = b.dataset.h; f.scrollIntoView({behavior: 'smooth'});
  });
  document.querySelectorAll('[data-ag]').forEach(el => el.onclick = () => {
    const a = db.ag.find(x => x.id == el.dataset.ag);
    a.status = STATUS[(STATUS.indexOf(a.status) + 1) % STATUS.length]; salvar(); rota();
  });
  const ft = $('#fTutor');
  if (ft) ft.onsubmit = e => { e.preventDefault(); const d = Object.fromEntries(new FormData(ft));
    db.tutores.push({id: proxId(db.tutores), ...d}); salvar(); rota(); };
  const fp = $('#fPet');
  if (fp) fp.onsubmit = e => { e.preventDefault(); const d = Object.fromEntries(new FormData(fp)); d.tutor = +d.tutor;
    db.pets.push({id: proxId(db.pets), ...d}); salvar(); rota(); };
  const sel = $('#selPet');
  if (sel) sel.onchange = () => location.hash = '#prontuario/' + sel.value;
  document.querySelectorAll('[data-lem]').forEach(b => b.onclick = () => {
    const v = db.vacinas[b.dataset.lem], p = pet(v.pet);
    v.enviado = true; salvar();
    const msg = `Olá, ${tutor(p.tutor).nome.split(' ')[0]}! 🐾 Aqui é a PetVida. O item “${v.nome}” do(a) ${p.nome} é para ${fmt(v.proxima)}. Responda esta mensagem para escolher o melhor horário!`;
    rota(); $('#previa').innerHTML = `<h2>Mensagem enviada (simulação)</h2><div class="zap">${esc(msg)}</div>`;
  });
}

$('#reset').onclick = () => { db = structuredClone(DADOS); salvar(); rota(); };
window.addEventListener('hashchange', rota);
rota();
